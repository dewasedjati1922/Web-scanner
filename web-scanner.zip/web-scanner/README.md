# Web Scanner (Educational)

![Python CI](https://github.com/dewasedjati1922/web-scanner/actions/workflows/python.yml/badge.svg)

⚠️ Warning: This tool is for educational use only. Do not scan targets without permission.

## ✨ Features
- Crawl website links
- Detect **XSS** & **SQL Injection**
- Directory fuzzing
- Admin panel finder
- Basic login brute force
- TCP Port scanner
- Reports in TXT, HTML, and PDF

## 📦 Install
```bash
git clone https://github.com/dewasedjati1922/web-scanner.git
cd web-scanner
pip install -r requirements.txt